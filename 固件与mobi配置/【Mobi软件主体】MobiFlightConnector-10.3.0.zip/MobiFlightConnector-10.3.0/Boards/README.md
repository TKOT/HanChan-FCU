﻿# MobiFlight Custom boards and devices

## Installation
https://github.com/MobiFlight/MobiFlight-Connector/wiki/Adding-a-custom-board-to-MobiFlight

## Developing your own devices
see https://github.com/MobiFlight/MobiFlight-Connector/wiki/How-to-setup-a-custom-device
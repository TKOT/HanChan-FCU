# Fenix A320 Config Files

There are 2 variants of the Fenix here:

1) Fenix A320 config file for Fenix v2.0.0.378 - It still requires the Fenix Quartz plugin.
2) Fenix A320 config file for Fenix v2.0.0.392 - Uses the new native Fenix LVARS, and does __NOT__ require the Quartz plugin.

There is a full cockpit profile for the v2.0.0.392 variant only.

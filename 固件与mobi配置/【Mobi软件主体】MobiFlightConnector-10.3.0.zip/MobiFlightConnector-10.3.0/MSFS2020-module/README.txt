Simply copy the whole folder

mobiflight-event-module

into your MSFS2020 Community Folder, e.g. C:\MSFS2020\Community